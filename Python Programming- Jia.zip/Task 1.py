import os

# Outline the name of the record wherein obligations may be saved
TODO_FILE = 'todo.txt'

# Function to load responsibilities from the file
def load_tasks():
    # Test if the document exists
    if not os.path.exists(TODO_FILE):
        # If the document does not exist, return an empty listing
        return []

    # Open the report in study mode
    with open(TODO_FILE, 'r') as file:
        # Read all traces from the report
        tasks = file.readlines()

    # Do away with any main/trailing whitespace (like newlines) from every venture
    return [task.strip() for task in tasks]

# Characteristic to store obligations to the document
def save_tasks(tasks):
    # Open the document in write mode
    with open(TODO_FILE, 'w') as file:
        # Write every mission to the file
        for task in tasks:
            file.write(task + '\n')

# Feature to feature a brand new undertaking
def add_task():
    # Get the brand new undertaking from the user
    task = input("Enter the new task: ")
    # Load current responsibilities
    tasks = load_tasks()
    # Add the new mission to the list
    tasks.append(task)
    # Shop the updated listing of responsibilities
    save_tasks(tasks)
    print("Task added efficiently!")

# Feature to view all duties
def view_tasks():
    # Load present responsibilities
    tasks = load_tasks()
    if not tasks:
        # If no tasks are found, print a message
        print("No tasks found!")
    else:
        # Print each task with its number
        for idx, task in enumerate(tasks, start=1):
            print(f"{idx}. {task}")

# Function to update an present project
def update_task():
    # Display all duties to the person
    view_tasks()
    # Get the undertaking range to replace
    task_num = int(input("Enter the mission range to update: ")) - 1
    # Load existing tasks
    tasks = load_tasks()
    if 0 <= task_num < len(tasks):
        # Get the updated task from the consumer
        new_task = input("Enter the updated challenge: ")
        # Update the project in the listing
        tasks[task_num] = new_task
        # Shop the updated list of obligations
        save_tasks(tasks)
        print("Task updated correctly!")
    else:
        # If the challenge number is invalid, print an errors message
        print("Invalid challenge range!")

# Function to delete an present assignment
def delete_task():
    # Show all tasks to the person
    view_tasks()
    # Get the task quantity to delete
    task_num = int(input("Enter the venture variety to delete: ")) - 1
    # Load present responsibilities
    tasks = load_tasks()
    if 0 <= task_num < len(tasks):
        # Remove the mission from the listing
        tasks.pop(task_num)
        # Save the updated listing of tasks
        save_tasks(tasks)
        print("Task deleted effectively!")
    else:
        # If the assignment range is invalid, print an blunders message
        print("Invalid venture quantity!")

# Function to mark a venture as completed
def mark_task_completed():
    # Show all responsibilities to the user
    view_tasks()
    # Get the task variety to mark as finished
    task_num = int(input("Enter the venture range to mark as finished: ")) - 1
    # Load current tasks
    tasks = load_tasks()
    if 0 <= task_num < len(tasks):
        # Append "[Completed]" to the venture
        tasks[task_num] = tasks[task_num] + " [Completed]"
        # Store the updated list of obligations
        save_tasks(tasks)
        print("Assignment marked as completed!")
    else:
        # If the venture quantity is invalid, print an error message
        print("Invalid task variety!")

# Predominant characteristic to run the software
def main():
    while True:
        # Print the menu options
        print("\nTo-Do List Application")
        print("1. Add task")
        print("2. View tasks")
        print("3. Update task")
        print("4. Delete task")
        print("5. Mark task as completed")
        print("6. Exit")

        # Get the user's desire
        choice = input("Enter your desire: ")
        if choice == '1':
            add_task()
        elif choice == '2':
            view_tasks()
        elif choice == '3':
            update_task()
        elif choice == '4':
            delete_task()
        elif choice == '5':
            mark_task_completed()
        elif choice == '6':
            print("Exiting the application. Goodbye!")
            break
        else:
            print("Invalid preference! Please try once more.")

# Run the main feature if this script is executed
if __name__ == "__main__":
    main()
