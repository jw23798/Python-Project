import random

def get_user_choice():
    # Prompt the user to choose rock, paper, or scissors
    while True:
        choice = input("Enter your choice (rock, paper, or scissors): ").lower()
        if choice in ['rock', 'paper', 'scissors']:
            return choice
        else:
            print("Oops! That's not a valid choice. Please enter 'rock', 'paper', or 'scissors'.")

def get_computer_choice():
    # Generate a random choice for the computer
    return random.choice(['rock', 'paper', 'scissors'])

def determine_winner(user_choice, computer_choice):
    # Determine the winner based on the user's choice and the computer's choice
    if user_choice == computer_choice:
        return "It's a tie!"
    elif (user_choice == 'rock' and computer_choice == 'scissors') or \
            (user_choice == 'scissors' and computer_choice == 'paper') or \
            (user_choice == 'paper' and computer_choice == 'rock'):
        return "Congratulations! You win!"
    else:
        return "Oops! You lose this round."

def main():
    user_score = 0
    computer_score = 0

    print("Welcome to the Rock-Paper-Scissors Game!")

    while True:
        # Get choices
        user_choice = get_user_choice()
        computer_choice = get_computer_choice()

        # Determine and display the winner
        result = determine_winner(user_choice, computer_choice)
        print(f"\nYou chose: {user_choice}")
        print(f"Computer chose: {computer_choice}")
        print(result)

        # Update and display scores
        if "win" in result:
            user_score += 1
        elif "lose" in result:
            computer_score += 1

        print(f"\nScores - You: {user_score}, Computer: {computer_score}")

        # Ask the user if they want to play again
        play_again = input("\nDo you want to play another round? (yes/no): ").lower()
        if play_again != 'yes':
            print("Thank you for playing! Have a great day!")
            break

# Run the main function if this script is executed
if __name__ == "__main__":
    main()
