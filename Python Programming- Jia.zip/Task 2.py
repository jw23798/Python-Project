def add(a, b):
    # This function takes two numbers and returns their sum
    return a + b

def subtract(a, b):
    # This function takes two numbers and returns the end result of subtracting the second number from the first
    return a - b

def multiply(a, b):
    # This function takes two numbers and returns their product
    return a * b

def divide(a, b):
    # This function takes two numbers and returns the end result of dividing the first number by the second
    # If the second number is zero, it returns an error message
    if b == 0:
        return "error: division by zero"
    return a / b

def main():
    # Show a menu of operations for the user to pick from
    print("Simple Calculator")
    print("Pick operation:")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")

    # Prompt the user to enter their choice of operation
    choice = input("Enter choice (1/2/3/4): ")

    # Check if the choice is valid (i.e., one of '1', '2', '3', '4')
    if choice in ['1', '2', '3', '4']:
        # Prompt the user to enter two numbers for the calculation
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        # Perform the corresponding operation based on the user's choice
        if choice == '1':
            # If the user selected addition
            print(f"{num1} + {num2} = {add(num1, num2)}")

        elif choice == '2':
            # If the user chose subtraction
            print(f"{num1} - {num2} = {subtract(num1, num2)}")

        elif choice == '3':
            # If the user selected multiplication
            print(f"{num1} * {num2} = {multiply(num1, num2)}")

        elif choice == '4':
            # If the user selected division
            result = divide(num1, num2)
            if result == "error: division by zero":
                print(result)
            else:
                print(f"{num1} / {num2} = {result}")

    else:
        # If the user enters an invalid choice
        print("Invalid input")

# Run the main function if this script is executed
if __name__ == "__main__":
    main()
