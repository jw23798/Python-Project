# Initialize an empty dictionary to save contacts
contacts = {}

def add_contact(name, phone, email, address):
    # Function to add a new contact
    contacts[name] = {
        'phone': phone,
        'email': email,
        'address': address
    }
    print(f"Contact '{name}' added successfully!")

def view_contacts():
    # Function to view all contacts
    if not contacts:
        print("No contacts found.")
    else:
        print("\nContact list:")
        for name, info in contacts.items():
            print(f"Name: {name}")
            print(f"Phone: {info['phone']}")
            print(f"Email: {info['email']}")
            print(f"Address: {info['address']}")
            print("-" * 20)

def search_contact(query):
    # Function to search for a contact by name or phone number
    found = False
    query = query.lower()
    for name, info in contacts.items():
        if query in name.lower() or query in info['phone']:
            print(f"\nName: {name}")
            print(f"Phone: {info['phone']}")
            print(f"Email: {info['email']}")
            print(f"Address: {info['address']}")
            print("-" * 20)
            found = True
    if not found:
        print("No matching contacts found.")

def update_contact(name, phone, email, address):
    # Function to update an existing contact
    if name in contacts:
        contacts[name] = {
            'phone': phone,
            'email': email,
            'address': address
        }
        print(f"Contact '{name}' updated successfully!")
    else:
        print(f"Contact '{name}' not found.")

def delete_contact(name):
    # Function to delete a contact
    if name in contacts:
        del contacts[name]
        print(f"Contact '{name}' deleted successfully!")
    else:
        print(f"Contact '{name}' not found.")

def main():
    # Main function to run the contact management system
    print("Welcome to the Contact Management System!")

    while True:
        print("\nMenu:")
        print("1. Add a new contact")
        print("2. View all contacts")
        print("3. Search for a contact")
        print("4. Update a contact")
        print("5. Delete a contact")
        print("6. Exit")

        choice = input("Enter your choice (1-6): ")

        if choice == '1':
            # Option to add a new contact
            print("\nAdd a New Contact:")
            name = input("Enter contact name: ")
            phone = input("Enter phone number: ")
            email = input("Enter email address: ")
            address = input("Enter address: ")
            add_contact(name, phone, email, address)

        elif choice == '2':
            # Option to view all contacts
            print("\nView All Contacts:")
            view_contacts()

        elif choice == '3':
            # Option to search for a contact
            print("\nSearch for a Contact:")
            query = input("Enter name or phone number to search: ")
            search_contact(query)

        elif choice == '4':
            # Option to update an existing contact
            print("\nUpdate a Contact:")
            name = input("Enter contact name to update: ")
            phone = input("Enter new phone number: ")
            email = input("Enter new email address: ")
            address = input("Enter new address: ")
            update_contact(name, phone, email, address)

        elif choice == '5':
            # Option to delete a contact
            print("\nDelete a Contact:")
            name = input("Enter contact name to delete: ")
            delete_contact(name)

        elif choice == '6':
            # Exit the program
            print("\nExiting the program. Goodbye!")
            break

        else:
            # Handle invalid choices
            print("Invalid choice. Please enter a number between 1 and 6.")

# Run the main function if this script is executed
if __name__ == "__main__":
    main()
